if (performance.navigation.type === 2) {
    session_start();
    session_destroy();
  }